﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace emailchecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string str = "if you care@domain employee-care@domain.com have contact@ any problem comment below. please  peter.parker@zylker.com like, share and subscribe the channel. contact@domain.com Contact me on hamzahumzahamzah@gmail.com if you need any custom software, website and mobile Application.";
            var regex = new Regex(@"[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?");
            var r = regex.Matches(str).Cast<Match>().Select(m => m.Value).ToArray();
            foreach(string s in r)
            {
                MessageBox.Show(s);
            }
        }
    }
}
